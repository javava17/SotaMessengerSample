//このソースは、VstoneMagicによって自動生成されました。
//ソースの内容を書き換えた場合、VstoneMagicで開けなくなる場合があります。
package	jp.co.mysota;
import	main.main.GlobalVariable;
import	jp.vstone.RobotLib.*;
import	jp.vstone.sotatalk.*;
import	jp.vstone.sotatalk.SpeechRecog.*;

public class Recommend
{

	public String speechRecogResult;
	public jp.co.mysota.End End;
	public Recommend()																									//@<BlockInfo>jp.vstone.block.func.constructor,16,16,272,16,False,3,@</BlockInfo>
	{
																														//@<OutputChild>
		/*String speechRecogResult*/;																					//@<BlockInfo>jp.vstone.block.variable,80,16,80,16,False,2,break@</BlockInfo>
																														//@<EndOfBlock/>
		End=new jp.co.mysota.End();																						//@<BlockInfo>jp.vstone.block.variable,144,16,144,16,False,1,break@</BlockInfo>
																														//@<EndOfBlock/>
																														//@</OutputChild>
	}																													//@<EndOfBlock/>

	//@<Separate/>
	public void recommend()																								//@<BlockInfo>jp.vstone.block.func,48,352,672,352,False,8,@</BlockInfo>
	throws SpeechRecogAbortException {
		if(!GlobalVariable.TRUE) throw new SpeechRecogAbortException("default");

																														//@<OutputChild>
		GlobalVariable.sotawish.Say((String)"この商品はいかがですか？",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);	//@<BlockInfo>jp.vstone.block.talk.say,112,352,112,352,False,7,@</BlockInfo>
																														//@<EndOfBlock/>
		GlobalVariable.sotawish.Say((String)"こちらの商品は満足いただけましたか？",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);	//@<BlockInfo>jp.vstone.block.talk.say,240,352,240,352,False,6,@</BlockInfo>
																														//@<EndOfBlock/>
		speechRecogResult = GlobalVariable.recog.getYesorNowithAbort((int)60000 , (int)3);								//@<BlockInfo>jp.vstone.block.talk.getyesno,304,256,496,256,False,5,音声認識を行い、肯定/否定を取得する。取得結果はメンバー変数のspeechRecogResultに格納され、肯定なら「YES」、否定なら「NO」、聞き取り失敗なら長さ0の文字列が代入される。@</BlockInfo>
		if(speechRecogResult==null) speechRecogResult="";

		if(speechRecogResult.equals("YES"))
		{
																														//@<OutputChild>
			End.end();																									//@<BlockInfo>jp.vstone.block.callfunc.base,368,256,368,256,False,4,@</BlockInfo>	@<EndOfBlock/>
																														//@</OutputChild>

		}else if(speechRecogResult.equals("NO"))
		{
																														//@<OutputChild>
																														//@</OutputChild>

		}else
		{
																														//@<OutputChild>
																														//@</OutputChild>

		}
																														//@<EndOfBlock/>
																														//@</OutputChild>

	}																													//@<EndOfBlock/>

}
