//このソースは、VstoneMagicによって自動生成されました。
//ソースの内容を書き換えた場合、VstoneMagicで開けなくなる場合があります。
package	jp.co.mysota;
import	main.main.GlobalVariable;
import	jp.vstone.RobotLib.*;
import	jp.vstone.sotatalk.*;
import	jp.vstone.sotatalk.SpeechRecog.*;
import	jp.vstone.camera.*;

public class Start
{

	public String speechRecogResult;
	public jp.co.mysota.WebsocketMessenger WebsocketMessenger;
	public RecogResult recogresult;
	public jp.co.mysota.End End;
	public Start()																										//@<BlockInfo>jp.vstone.block.func.constructor,16,16,656,16,False,5,@</BlockInfo>
	{
																														//@<OutputChild>
		/*String speechRecogResult*/;																					//@<BlockInfo>jp.vstone.block.variable,80,16,80,16,False,4,break@</BlockInfo>
																														//@<EndOfBlock/>
		WebsocketMessenger=new jp.co.mysota.WebsocketMessenger();														//@<BlockInfo>jp.vstone.block.variable,144,16,144,16,False,3,break@</BlockInfo>
																														//@<EndOfBlock/>
		/*RecogResult recogresult*/;																					//@<BlockInfo>jp.vstone.block.variable,208,16,208,16,False,2,break@</BlockInfo>
																														//@<EndOfBlock/>
		End=new jp.co.mysota.End();																						//@<BlockInfo>jp.vstone.block.variable,272,16,272,16,False,1,break@</BlockInfo>
																														//@<EndOfBlock/>
																														//@</OutputChild>
	}																													//@<EndOfBlock/>

	//@<Separate/>
	public void method()																								//@<BlockInfo>jp.vstone.block.func,16,128,416,128,False,7,@</BlockInfo>
	throws SpeechRecogAbortException {
		if(!GlobalVariable.TRUE) throw new SpeechRecogAbortException("default");

																														//@<OutputChild>
		start();																										//@<BlockInfo>jp.vstone.block.callfunc.base,192,128,192,128,False,6,@</BlockInfo>	@<EndOfBlock/>
																														//@</OutputChild>

	}																													//@<EndOfBlock/>

	//@<Separate/>
	public void start()																									//@<BlockInfo>jp.vstone.block.func,0,304,960,304,False,18,@</BlockInfo>
	throws SpeechRecogAbortException {
		if(!GlobalVariable.TRUE) throw new SpeechRecogAbortException("default");

																														//@<OutputChild>
		GlobalVariable.robocam.setEnableFaceSearch(false);																//@<BlockInfo>jp.vstone.block.facedetect.traking,64,304,896,304,False,17,顔追従@</BlockInfo>
		GlobalVariable.robocam.setEnableSmileDetect(true);
		GlobalVariable.robocam.setEnableAgeSexDetect(true);

		GlobalVariable.robocam.StartFaceTraking();
		try{
			GlobalVariable.detectCount=0;


																														//@<OutputChild>
			WebsocketMessenger.connect((String)"ws://192.168.128.103:8080/ws");											//@<BlockInfo>jp.vstone.block.callfunc.base,128,304,128,304,False,16,@</BlockInfo>	@<EndOfBlock/>
			while(GlobalVariable.TRUE)																					//@<BlockInfo>jp.vstone.block.while.endless,208,304,832,304,False,15,Endless@</BlockInfo>
			{

																														//@<OutputChild>
				GlobalVariable.faceresult = GlobalVariable.robocam.getDetectResult();									//@<BlockInfo>jp.vstone.block.facedetect.isdetect,272,256,752,256,False,14,コメント@</BlockInfo>

				if(GlobalVariable.faceresult.isDetect()) GlobalVariable.detectCount++;
				else GlobalVariable.detectCount=0;

				if(GlobalVariable.detectCount>(int)2)
				{
																														//@<OutputChild>
					CRobotUtil.wait((int)1000);																			//@<BlockInfo>jp.vstone.block.wait,336,256,336,256,False,13,コメント@</BlockInfo>	@<EndOfBlock/>
					GlobalVariable.sotawish.Say((String)"性別を教えて",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);	//@<BlockInfo>jp.vstone.block.talk.say,400,256,400,256,False,12,@</BlockInfo>
																														//@<EndOfBlock/>
					speechRecogResult = GlobalVariable.recog.getResponsewithAbort((int)60000,(int)3);					//@<BlockInfo>jp.vstone.block.talk.speechrecog.get,480,256,480,256,False,11,音声認識して、得られた結果（文字列）をspeechRecogResultに代入します。@</BlockInfo>
					if(speechRecogResult == null) speechRecogResult = "";

																														//@<EndOfBlock/>
					WebsocketMessenger.sendMessage((String)speechRecogResult);											//@<BlockInfo>jp.vstone.block.callfunc.base,544,256,544,256,False,10,@</BlockInfo>	@<EndOfBlock/>
					initial();																							//@<BlockInfo>jp.vstone.block.callfunc.base,624,256,624,256,False,9,@</BlockInfo>	@<EndOfBlock/>
					break;																								//@<BlockInfo>jp.vstone.block.break,688,256,688,256,False,8,break@</BlockInfo>	@<EndOfBlock/>
																														//@</OutputChild>

				}else
				{
																														//@<OutputChild>
																														//@</OutputChild>

				}
																														//@<EndOfBlock/>
																														//@</OutputChild>
			}
																														//@<EndOfBlock/>
																														//@</OutputChild>


		}finally{
			GlobalVariable.robocam.StopFaceTraking();
		}
																														//@<EndOfBlock/>
																														//@</OutputChild>

	}																													//@<EndOfBlock/>

	//@<Separate/>
	public void initial()																								//@<BlockInfo>jp.vstone.block.func,32,560,592,560,False,24,@</BlockInfo>
	throws SpeechRecogAbortException {
		if(!GlobalVariable.TRUE) throw new SpeechRecogAbortException("default");

																														//@<OutputChild>
		CRobotUtil.wait((int)1000);																						//@<BlockInfo>jp.vstone.block.wait,96,560,96,560,False,23,コメント@</BlockInfo>	@<EndOfBlock/>
		GlobalVariable.sotawish.Say((String)"ですか",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);			//@<BlockInfo>jp.vstone.block.talk.say,176,560,176,560,False,22,@</BlockInfo>
																														//@<EndOfBlock/>
		speechRecogResult = GlobalVariable.recog.getYesorNowithAbort((int)60000 , (int)3);								//@<BlockInfo>jp.vstone.block.talk.getyesno,288,464,416,464,False,21,音声認識を行い、肯定/否定を取得する。取得結果はメンバー変数のspeechRecogResultに格納され、肯定なら「YES」、否定なら「NO」、聞き取り失敗なら長さ0の文字列が代入される。@</BlockInfo>
		if(speechRecogResult==null) speechRecogResult="";

		if(speechRecogResult.equals("YES"))
		{
																														//@<OutputChild>
			age();																										//@<BlockInfo>jp.vstone.block.callfunc.base,352,464,352,464,False,19,@</BlockInfo>	@<EndOfBlock/>
																														//@</OutputChild>

		}else if(speechRecogResult.equals("NO"))
		{
																														//@<OutputChild>
																														//@</OutputChild>

		}else
		{
																														//@<OutputChild>
			GlobalVariable.sotawish.Say((String)"もう一度お願いします",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);	//@<BlockInfo>jp.vstone.block.talk.say,352,656,352,656,False,20,@</BlockInfo>
																														//@<EndOfBlock/>
																														//@</OutputChild>

		}
																														//@<EndOfBlock/>
																														//@</OutputChild>

	}																													//@<EndOfBlock/>

	//@<Separate/>
	public void age()																									//@<BlockInfo>jp.vstone.block.func,0,912,848,912,False,35,@</BlockInfo>
	throws SpeechRecogAbortException {
		if(!GlobalVariable.TRUE) throw new SpeechRecogAbortException("default");

																														//@<OutputChild>
		for(int i=0;i<(int)2;i++)																						//@<BlockInfo>jp.vstone.block.for,64,912,784,912,False,34,コメント@</BlockInfo>
		{
																														//@<OutputChild>
			GlobalVariable.sotawish.Say((String)"幼稚園せいですか？小学生ですか？中学生ですか？",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);	//@<BlockInfo>jp.vstone.block.talk.say,128,912,128,912,False,33,@</BlockInfo>
																														//@<EndOfBlock/>
			speechRecogResult = GlobalVariable.recog.getResponsewithAbort((int)60000,(int)3);							//@<BlockInfo>jp.vstone.block.talk.speechrecog.get,208,912,208,912,False,32,音声認識して、得られた結果（文字列）をspeechRecogResultに代入します。@</BlockInfo>
			if(speechRecogResult == null) speechRecogResult = "";

																														//@<EndOfBlock/>
			WebsocketMessenger.sendMessage((String)speechRecogResult);													//@<BlockInfo>jp.vstone.block.callfunc.base,272,912,272,912,False,31,@</BlockInfo>	@<EndOfBlock/>
			CRobotUtil.wait((int)1000);																					//@<BlockInfo>jp.vstone.block.wait,336,912,336,912,False,30,コメント@</BlockInfo>	@<EndOfBlock/>
			GlobalVariable.sotawish.Say((String)"ですね",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);		//@<BlockInfo>jp.vstone.block.talk.say,400,912,400,912,False,29,@</BlockInfo>
																														//@<EndOfBlock/>
			speechRecogResult = GlobalVariable.recog.getYesorNowithAbort((int)60000 , (int)3);							//@<BlockInfo>jp.vstone.block.talk.getyesno,464,816,656,816,False,28,音声認識を行い、肯定/否定を取得する。取得結果はメンバー変数のspeechRecogResultに格納され、肯定なら「YES」、否定なら「NO」、聞き取り失敗なら長さ0の文字列が代入される。@</BlockInfo>
			if(speechRecogResult==null) speechRecogResult="";

			if(speechRecogResult.equals("YES"))
			{
																														//@<OutputChild>
				budget();																								//@<BlockInfo>jp.vstone.block.callfunc.base,528,816,528,816,False,26,@</BlockInfo>	@<EndOfBlock/>
				break;																									//@<BlockInfo>jp.vstone.block.break,592,816,592,816,False,25,break@</BlockInfo>	@<EndOfBlock/>
																														//@</OutputChild>

			}else if(speechRecogResult.equals("NO"))
			{
																														//@<OutputChild>
																														//@</OutputChild>

			}else
			{
																														//@<OutputChild>
				GlobalVariable.sotawish.Say((String)"もう一度お願いします",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);	//@<BlockInfo>jp.vstone.block.talk.say,528,1008,528,1008,False,27,@</BlockInfo>
																														//@<EndOfBlock/>
																														//@</OutputChild>

			}
																														//@<EndOfBlock/>
																														//@</OutputChild>
		}																												//@<EndOfBlock/>
																														//@</OutputChild>

	}																													//@<EndOfBlock/>

	//@<Separate/>
	public void budget()																								//@<BlockInfo>jp.vstone.block.func,0,1248,800,1232,False,46,@</BlockInfo>
	throws SpeechRecogAbortException {
		if(!GlobalVariable.TRUE) throw new SpeechRecogAbortException("default");

																														//@<OutputChild>
		for(int i=0;i<(int)2;i++)																						//@<BlockInfo>jp.vstone.block.for,64,1248,736,1232,False,45,コメント@</BlockInfo>
		{
																														//@<OutputChild>
			GlobalVariable.sotawish.Say((String)"予算はいくらまでですか",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);	//@<BlockInfo>jp.vstone.block.talk.say,128,1248,128,1248,False,44,@</BlockInfo>
																														//@<EndOfBlock/>
			speechRecogResult = GlobalVariable.recog.getResponsewithAbort((int)60000,(int)3);							//@<BlockInfo>jp.vstone.block.talk.speechrecog.get,208,1248,208,1248,False,43,音声認識して、得られた結果（文字列）をspeechRecogResultに代入します。@</BlockInfo>
			if(speechRecogResult == null) speechRecogResult = "";

																														//@<EndOfBlock/>
			WebsocketMessenger.sendMessage((String)speechRecogResult);													//@<BlockInfo>jp.vstone.block.callfunc.base,272,1248,272,1248,False,42,@</BlockInfo>	@<EndOfBlock/>
			CRobotUtil.wait((int)1000);																					//@<BlockInfo>jp.vstone.block.wait,336,1248,336,1248,False,41,コメント@</BlockInfo>	@<EndOfBlock/>
			GlobalVariable.sotawish.Say((String)"ですね",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);		//@<BlockInfo>jp.vstone.block.talk.say,400,1248,400,1248,False,40,@</BlockInfo>
																														//@<EndOfBlock/>
			speechRecogResult = GlobalVariable.recog.getYesorNowithAbort((int)60000 , (int)3);							//@<BlockInfo>jp.vstone.block.talk.getyesno,464,1152,656,1152,False,39,音声認識を行い、肯定/否定を取得する。取得結果はメンバー変数のspeechRecogResultに格納され、肯定なら「YES」、否定なら「NO」、聞き取り失敗なら長さ0の文字列が代入される。@</BlockInfo>
			if(speechRecogResult==null) speechRecogResult="";

			if(speechRecogResult.equals("YES"))
			{
																														//@<OutputChild>
				interest();																								//@<BlockInfo>jp.vstone.block.callfunc.base,528,1152,528,1152,False,37,@</BlockInfo>	@<EndOfBlock/>
				break;																									//@<BlockInfo>jp.vstone.block.break,592,1152,592,1152,False,36,break@</BlockInfo>	@<EndOfBlock/>
																														//@</OutputChild>

			}else if(speechRecogResult.equals("NO"))
			{
																														//@<OutputChild>
																														//@</OutputChild>

			}else
			{
																														//@<OutputChild>
				GlobalVariable.sotawish.Say((String)"もう一度お願いします",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);	//@<BlockInfo>jp.vstone.block.talk.say,528,1344,528,1344,False,38,@</BlockInfo>
																														//@<EndOfBlock/>
																														//@</OutputChild>

			}
																														//@<EndOfBlock/>
																														//@</OutputChild>
		}																												//@<EndOfBlock/>
																														//@</OutputChild>

	}																													//@<EndOfBlock/>

	//@<Separate/>
	public void interest()																								//@<BlockInfo>jp.vstone.block.func,0,1552,848,1552,False,57,@</BlockInfo>
	throws SpeechRecogAbortException {
		if(!GlobalVariable.TRUE) throw new SpeechRecogAbortException("default");

																														//@<OutputChild>
		for(int i=0;i<(int)2;i++)																						//@<BlockInfo>jp.vstone.block.for,64,1552,784,1552,False,56,コメント@</BlockInfo>
		{
																														//@<OutputChild>
			GlobalVariable.sotawish.Say((String)"その人の趣味はなんですか？",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);	//@<BlockInfo>jp.vstone.block.talk.say,128,1552,128,1552,False,55,@</BlockInfo>
																														//@<EndOfBlock/>
			speechRecogResult = GlobalVariable.recog.getResponsewithAbort((int)60000,(int)3);							//@<BlockInfo>jp.vstone.block.talk.speechrecog.get,208,1552,208,1552,False,54,音声認識して、得られた結果（文字列）をspeechRecogResultに代入します。@</BlockInfo>
			if(speechRecogResult == null) speechRecogResult = "";

																														//@<EndOfBlock/>
			WebsocketMessenger.sendMessage((String)speechRecogResult);													//@<BlockInfo>jp.vstone.block.callfunc.base,272,1552,272,1552,False,53,@</BlockInfo>	@<EndOfBlock/>
			CRobotUtil.wait((int)1000);																					//@<BlockInfo>jp.vstone.block.wait,336,1552,336,1552,False,52,コメント@</BlockInfo>	@<EndOfBlock/>
			GlobalVariable.sotawish.Say((String)"ですね",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);		//@<BlockInfo>jp.vstone.block.talk.say,400,1552,400,1552,False,51,@</BlockInfo>
																														//@<EndOfBlock/>
			speechRecogResult = GlobalVariable.recog.getYesorNowithAbort((int)60000 , (int)3);							//@<BlockInfo>jp.vstone.block.talk.getyesno,464,1456,656,1456,False,50,音声認識を行い、肯定/否定を取得する。取得結果はメンバー変数のspeechRecogResultに格納され、肯定なら「YES」、否定なら「NO」、聞き取り失敗なら長さ0の文字列が代入される。@</BlockInfo>
			if(speechRecogResult==null) speechRecogResult="";

			if(speechRecogResult.equals("YES"))
			{
																														//@<OutputChild>
				recommend();																							//@<BlockInfo>jp.vstone.block.callfunc.base,528,1456,528,1456,False,48,@</BlockInfo>	@<EndOfBlock/>
				break;																									//@<BlockInfo>jp.vstone.block.break,592,1456,592,1456,False,47,break@</BlockInfo>	@<EndOfBlock/>
																														//@</OutputChild>

			}else if(speechRecogResult.equals("NO"))
			{
																														//@<OutputChild>
																														//@</OutputChild>

			}else
			{
																														//@<OutputChild>
				GlobalVariable.sotawish.Say((String)"もう一度お願いします",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);	//@<BlockInfo>jp.vstone.block.talk.say,528,1648,528,1648,False,49,@</BlockInfo>
																														//@<EndOfBlock/>
																														//@</OutputChild>

			}
																														//@<EndOfBlock/>
																														//@</OutputChild>
		}																												//@<EndOfBlock/>
																														//@</OutputChild>

	}																													//@<EndOfBlock/>

	//@<Separate/>
	public void recommend()																								//@<BlockInfo>jp.vstone.block.func,80,3984,704,3984,False,63,@</BlockInfo>
	throws SpeechRecogAbortException {
		if(!GlobalVariable.TRUE) throw new SpeechRecogAbortException("default");

																														//@<OutputChild>
		GlobalVariable.sotawish.Say((String)"この商品はいかがですか？",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);	//@<BlockInfo>jp.vstone.block.talk.say,144,3984,144,3984,False,62,@</BlockInfo>
																														//@<EndOfBlock/>
		WebsocketMessenger.sendMessage((String)speechRecogResult);														//@<BlockInfo>jp.vstone.block.callfunc.base,208,3984,208,3984,False,61,@</BlockInfo>	@<EndOfBlock/>
		GlobalVariable.sotawish.Say((String)"こちらの商品は満足いただけましたか？",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);	//@<BlockInfo>jp.vstone.block.talk.say,272,3984,272,3984,False,60,@</BlockInfo>
																														//@<EndOfBlock/>
		speechRecogResult = GlobalVariable.recog.getYesorNowithAbort((int)60000 , (int)3);								//@<BlockInfo>jp.vstone.block.talk.getyesno,352,3888,528,3888,False,59,音声認識を行い、肯定/否定を取得する。取得結果はメンバー変数のspeechRecogResultに格納され、肯定なら「YES」、否定なら「NO」、聞き取り失敗なら長さ0の文字列が代入される。@</BlockInfo>
		if(speechRecogResult==null) speechRecogResult="";

		if(speechRecogResult.equals("YES"))
		{
																														//@<OutputChild>
			End.end();																									//@<BlockInfo>jp.vstone.block.callfunc.base,416,3888,416,3888,False,58,@</BlockInfo>	@<EndOfBlock/>
																														//@</OutputChild>

		}else if(speechRecogResult.equals("NO"))
		{
																														//@<OutputChild>
																														//@</OutputChild>

		}else
		{
																														//@<OutputChild>
																														//@</OutputChild>

		}
																														//@<EndOfBlock/>
																														//@</OutputChild>

	}																													//@<EndOfBlock/>

	//@<Separate/>
	public void ask()																									//@<BlockInfo>jp.vstone.block.func,0,1984,608,1984,False,70,@</BlockInfo>
	throws SpeechRecogAbortException {
		if(!GlobalVariable.TRUE) throw new SpeechRecogAbortException("default");

																														//@<OutputChild>
		for(int i=0;i<(int)2;i++)																						//@<BlockInfo>jp.vstone.block.for,64,1984,608,1984,False,69,コメント@</BlockInfo>
		{
																														//@<OutputChild>
			GlobalVariable.sotawish.Say((String)"その人は外で遊ぶのが好きですか？",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);	//@<BlockInfo>jp.vstone.block.talk.say,128,1984,128,1984,False,68,@</BlockInfo>
																														//@<EndOfBlock/>
			speechRecogResult = GlobalVariable.recog.getYesorNowithAbort((int)60000 , (int)3);							//@<BlockInfo>jp.vstone.block.talk.getyesno,208,1888,480,1888,False,67,音声認識を行い、肯定/否定を取得する。取得結果はメンバー変数のspeechRecogResultに格納され、肯定なら「YES」、否定なら「NO」、聞き取り失敗なら長さ0の文字列が代入される。@</BlockInfo>
			if(speechRecogResult==null) speechRecogResult="";

			if(speechRecogResult.equals("YES"))
			{
																														//@<OutputChild>
				speechRecogResult = "外遊び";	
				print(speechRecogResult);
																					//@<BlockInfo>jp.vstone.block.freeproc,272,1888,272,1888,False,71,@</BlockInfo>
																														//@<EndOfBlock/>
				recommend();																							//@<BlockInfo>jp.vstone.block.callfunc.base,352,1888,352,1888,False,65,@</BlockInfo>	@<EndOfBlock/>
				break;																									//@<BlockInfo>jp.vstone.block.break,416,1888,416,1888,False,64,break@</BlockInfo>	@<EndOfBlock/>
																														//@</OutputChild>

			}else if(speechRecogResult.equals("NO"))
			{
																														//@<OutputChild>
																														//@</OutputChild>

			}else
			{
																														//@<OutputChild>
				GlobalVariable.sotawish.Say((String)"もう一度お願いします",MotionAsSotaWish.MOTION_TYPE_TALK,(int)11,(int)13,(int)11);	//@<BlockInfo>jp.vstone.block.talk.say,272,2080,272,2080,False,66,@</BlockInfo>
																														//@<EndOfBlock/>
																														//@</OutputChild>

			}
																														//@<EndOfBlock/>
																														//@</OutputChild>
		}																												//@<EndOfBlock/>
																														//@</OutputChild>

	}																													//@<EndOfBlock/>

}
